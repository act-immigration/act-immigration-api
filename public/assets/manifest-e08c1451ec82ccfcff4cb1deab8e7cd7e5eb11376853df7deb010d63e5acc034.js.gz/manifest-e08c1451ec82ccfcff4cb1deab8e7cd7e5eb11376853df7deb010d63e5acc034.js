// Empty manifest file for API-only applicationp;
